//: # Chiamare funzioni con valore di ritorno
//: ### Funzioni Void
func hello() {
    print("Hello!")
}
//: ### Valori di ritorno
func recuperaTemperatura() -> Int? {
    let sensoreAttivo = false
    if sensoreAttivo {
        return 28
    }
    
    return nil
}

let temperatura = recuperaTemperatura()
print(temperatura)
//: ### Valori di ritorno multipli
func calcolaTemperature() -> (min: Int, max: Int) {
    return (min: 16, max: 29)
}

let temperature = calcolaTemperature()
temperature.min
temperature.max

