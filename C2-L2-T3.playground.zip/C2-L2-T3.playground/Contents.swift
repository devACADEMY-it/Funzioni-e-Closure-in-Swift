//: # Omettere il nome del parametro
func hello(_ name: String, _ city: String) {
    print("Ciao, \(name) ti torvi nella città \(city)")
}

hello("Massimo", "Milano")
