//: # .map
let numbers = [4, 7, 3]

let result = numbers.map { num -> Int in
    return num * 2
}

print(result)

let strings = numbers.map { num -> String in
    return "\(num)"
}
