//: # Funzioni globali
//: ### print e debugPrint
print("Ciao")
print("Ciao", "come", "stai?", separator: "-", terminator: "\n\n")
print("Ciao")

let names: Set<String> = ["Maria", "Francesca", "Marco"]
print(names)
debugPrint(names)
