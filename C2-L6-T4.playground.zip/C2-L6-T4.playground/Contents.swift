//: # .reduce
let numbers = [3, 4, 5]

let result = numbers.reduce(10) { (result, num) in
    print("result: \(result)")
    return result + num
}

print(result)

let words = ["Ciao", "come", "stai?"]

let result1 = words.reduce("Domanda:") { (result, word) in
    result + " " + word
}

print(result1)
