//: # Valore di default di un parametro
func hello(name: String = "Anonimo", city: String = "Roma") {
    print("Ciao, \(name) ti trovi nella città \(city)")
}

hello(name: "Massimo", city: "Milano")
hello(city: "Milano")
hello(name: "Carlo")
hello()
