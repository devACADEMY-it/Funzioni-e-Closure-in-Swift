//: # Funzioni globali
//: ### zip
let aziende = ["Acme Spa", "Oliver Inc", "Magneti Srl"]
let dipendenti = [5, 234, 567]

let result = zip(aziende, dipendenti)

for item in result {
    print("Azienda \(item.0) dipendenti \(item.1)")
}

//: repeatElement
let repeatResult = repeatElement("ciao", count: 100)
for item in repeatResult {
    print("item \(item)")
}


let repeatResult1 = repeatElement(20.8, count: 100)
for item in repeatResult1 {
    print("item \(item)")
}
