//: # Parametri In-Out
var i = 3

func increment(value: inout Int, quantity: Int) -> Void {
    value += quantity
}

increment(value: &i, quantity: 5)

print("Il valore di i è \(i)")
