//: # Passaggio dei parametri
func hello(yourname: String) {
    print("Ciao, \(yourname)")
}

hello(yourname: "Massimo")
hello(yourname: "Maria")
hello(yourname: "Franco")

func increment(value: Int, step: Int) -> Int {
    return value + step
}

let risultato = increment(value: 50, step: 2)

