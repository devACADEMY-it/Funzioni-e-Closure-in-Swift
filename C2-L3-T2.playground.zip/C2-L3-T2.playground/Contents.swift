//: # Funzioni come parametri di funzioni
func find(values: [String], finder: (String) -> Bool ) -> String? {
    for value in values {
        if finder(value) == true {
            return value
        }
    }
    
    return nil
}

func iniziaConFr(value: String) -> Bool {
    return value.hasPrefix("Fr")
}

func contine5Caratteri(value: String) -> Bool {
    return value.count == 5
}

let names = ["Massimo", "Carlo", "Francesca", "Maria"]
let result = find(values: names, finder: iniziaConFr)
let result2 = find(values: names, finder: contine5Caratteri)
