//: # Le funzioni e lo scope
//: * Identificatori definiti all'interno della funzione
//: * Identificatori definiti nel Global Scope
//: * Shadowing degli identificatori definiti nello scope esterno
var i = 0

func increment() {
    var i = 20
    var hello = "Ciao"
    i += 1
}

print("Valore di i = \(i)")
increment()
print("Valore di i = \(i)")
