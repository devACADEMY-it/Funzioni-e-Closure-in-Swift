//: # .flatMap
let numbers: [[Int]] = [  [3, 6, 9], [2, 1, 0]  ]

// [  [3, 6, 9], [2, 1, 0]  ]  --> [ 3, 6, 9, 2, 1, 0]

let result = numbers.flatMap { (arrayOfInts) in
    return arrayOfInts
}

print(result)


let names = [ ["Marco", "Massimo"], ["Maria", "Federica"] ]

let result1 = names.flatMap { return $0 }

print(result1)
