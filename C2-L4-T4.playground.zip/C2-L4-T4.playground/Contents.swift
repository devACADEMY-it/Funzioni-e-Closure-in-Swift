//: # Closure e forme contratte
/*:
     { (parameters) -> return type in
        ...statements...
     }
 */
let names = ["Marco", "Giovanni", "Francesca", "Maria"]
//: #### Forma 0: completa
names.sorted(by: { (n1: String, n2: String) -> Bool in
    return n1 < n2
})
//: #### Forma 1: type inference
names.sorted(by: { n1, n2 in
    return n1 < n2
})
//: #### Forma 2: return
names.sorted(by: { n1, n2 in n1 < n2 })
//: #### Forma 3: argument names
names.sorted(by: { $0 < $1 })
