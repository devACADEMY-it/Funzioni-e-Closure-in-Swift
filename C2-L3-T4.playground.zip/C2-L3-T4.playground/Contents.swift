//: # Funzioni annidate
//: ### Nested functions
enum Message {
    case hello
    case welcome
}

func hello(name: String) {
    
}

func choose(message: Message) ->  ((String) -> Void) {
    
    func hello(name: String) {
        print("Ciao, \(name)")
    }
    
    func welcome(name: String) {
        print("Benvenuto, \(name)")
    }
    
    switch message {
    case .hello:
        return hello
    case .welcome:
        return welcome
    }
}

let mexFunc = choose(message: .hello)
mexFunc("Massimo")
