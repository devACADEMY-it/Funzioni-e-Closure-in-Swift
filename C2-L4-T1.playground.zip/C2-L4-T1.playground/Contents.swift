//: # Le Closure
/*:
 Le Closure (_chiusure_) sono blocchi di codice autonomi (_simili alle funzioni_) che possono essere passati come parametro, messi in varibili o ritornati da un funzione.
 
 Le chiusure possono catturare e memorizzare riferimenti a qualsiasi costante o variabile dal contesto in cui sono definite. Questo processo è noto come *chiusura* (o _closing_) su quelle variabili, da qui il nome chiusure (_closure_).
 
 * Le funzioni sono in realtà casi speciali di closure
 * Le funzioni sono delle closure che hanno un nome
 * Le closure, così come le funzioni, sono considerate First-Class type
 ---
 
     { (parameters) -> return type in
        ...statements...
     }
 
 */
