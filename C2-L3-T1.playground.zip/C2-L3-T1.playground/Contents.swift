//: # Introduzione ai tipi funzione
/*:
 ### Le funzioni sono first-class type
 * Possono essere memorizzate in variabili e costanti
 * Possono essere passate come parametri
 * Possono essere ritornate come risultato di una funzione
 */
// (P1, P2, ...) -> T

// () -> Void   // Int
func hello() { print("hello") } // 5
func prova() { print("prova") } // 7

// (String) -> Void
func welcome(name: String) {}

// (Int, Int) -> Double
func increment(value: Int, quantity: Int) -> Double { return 0.0 }
func add(a1: Int, a2: Int) -> Double { return 1.0 }


var f1: () -> Void = hello
f1()
f1 = prova
f1()

var f3: (_ v1: Int, _ v2: Int) -> Double = increment
let result = f3(3, 5)

f3 = add
f3(7, 8)
