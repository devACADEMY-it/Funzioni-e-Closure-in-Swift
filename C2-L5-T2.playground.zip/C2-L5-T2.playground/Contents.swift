//: # Funzioni globali
//: ### dump e type(of:)
let numbers = [1, 5, 7, 0]

print(numbers)
dump(numbers)

let info = type(of: numbers)
print(info)

let prova = 2.0
print(type(of: prova))
