//: # Cattura dei valori
/*:
 Una _closure_ può catturare costanti e variabili create nel contesto circostante in cui è definita.
 
 La closure può accedere o modificare i valori di queste costanti e variabili all'interno del suo corpo, anche se il contesto (_scope_) in cui sono state definite non esiste più.
*/
func attivaTermostato() -> (Int) -> Void {
    var temperatura = 20
    
    let modificaTemperatura = { (gradi: Int) in
        temperatura += gradi
        print("Nuova temperatura: \(temperatura)")
    }
    
    return modificaTemperatura
}

let modifica = attivaTermostato()
modifica(1)
modifica(1)
