//: # .filter
let numbers = [4, 7, 9, 0]

let result = numbers.filter { num in
    return num >= 7
}

print(result)

let words = ["ciao", "casa", "moto", "auto"]

let result1 = words.filter { word in word.hasPrefix("c") }

print(result1)
