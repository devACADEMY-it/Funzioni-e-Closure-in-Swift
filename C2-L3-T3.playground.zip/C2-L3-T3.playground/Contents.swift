//: # Funzioni come ritorno di funzioni
func hello(name: String) {
    print("Ciao, \(name)")
}

func welcome(name: String) {
    print("Benvenuto, \(name)")
}

enum Message {
    case hello
    case welcome
}

func choose(message: Message) ->  ((String) -> Void) {
    switch message {
    case .hello:
        return hello
    case .welcome:
        return welcome
    }
}

let mexFunc = choose(message: .welcome)
mexFunc("Massimo")
