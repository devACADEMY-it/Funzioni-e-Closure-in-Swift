//: # Funzioni globali
//: ### numericCast
let val1: Int16 = 12345
let val2: Int32 = numericCast(val1)
let val3: UInt32 = numericCast(val1)
//: ### abs
abs(-4.9)
abs(-6)
//: ### max e min
max(3, -1)
min(3, -1)

max("A", "C")
min("A", "C")
