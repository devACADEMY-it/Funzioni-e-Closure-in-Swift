//: # Le Funzioni
/*
 1. nome
 2. parametri
 3. tipo di ritorno
 4. corpo
 */

func hello() -> Void {
    print("Hello!")
}

hello()
hello()
hello()
hello()
