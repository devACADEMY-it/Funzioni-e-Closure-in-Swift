//: # Parametri variadici
//: ### Variadic parameters
func hello(names: String...) {
    for name in names {
        print("Benvenuto \(name)")
    }
}

// hello(names: ["Massimo", "Carla", "Maria"])
hello(names: "Massimo", "Carla", "Maria")
