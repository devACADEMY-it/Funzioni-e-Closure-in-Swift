//: # High Order Functions
/*:
 ### Funzioni di ordine superiore
 Sono funzioni che hanno almeno una delle seguenti caratteristiche:
  * Prende in ingresso uno o più funzioni
  * Ritornano una funzione
 */
func logDebug(text: String) { // (String) -> Void
    debugPrint(text)
}

func logPrint(text: String) { // (String) -> Void
    print(text)
}

func log(text: String, logger: (String) -> Void) {
    logger(text)
}

log(text: "Prova", logger: logDebug)
log(text: "Prova", logger: logPrint)
