//: # Closure e type inference
/*:
     { (parameters) -> return type in
        ...statements...
     }
 */
let names = ["Massimo", "Angelo", "Maria", "Francesca"]

names.sorted(by: { (name1, name2) in
    return name1 < name2
})
