//: # Trailing Closure
let names = ["Maria", "Giuseppe", "Francesca", "Marco"]

names.sorted { n1, n2 in
    n1 < n2
}

func prova(closure: (Int) -> Int, count: Int) {}

prova(closure: { (p1) -> Int in return 1 }, count: 67)

func prova2(count: Int, closure: (Int) -> Int) { }


prova2(count: 2) { p1 in
    return p1 + 1
}
