//: # Sintassi fondamentale di una closure
/*:
     { (parameters) -> return type in
        ...statements...
     }
 */
let names = ["Massimo", "Angelo", "Francesca", "Maria"]

func sortByName(name1: String, name2: String) -> Bool {
    return name1 < name2
}

let result = names.sorted(by: sortByName)

let sorting = { (name1: String, names2: String) -> Bool in
    return names2 < name1
}

let result2 = names.sorted(by: sorting)
