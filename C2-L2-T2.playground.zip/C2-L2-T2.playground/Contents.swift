//: # Parametri esterni ed interni
//: ### Argument label e Parameter label
//: * __argument label__: usato quando si chiama la funzione
//: * __parameter label__: usato all'interno della funzione
func hello(name: String) {
    print("Ciao, \(name)")
}

hello(name: "Massimo")


func move(from city1: String, to city2: String) {
    print("Mi muovo da \(city1) verso \(city2)")
}

move(from: "Milano", to: "Roma")
